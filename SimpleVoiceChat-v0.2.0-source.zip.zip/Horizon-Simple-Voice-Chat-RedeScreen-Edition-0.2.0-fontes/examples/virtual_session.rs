// Invoked by tests/interop only. The peer and both ALSA devices are local test fixtures.
#[cfg(feature = "devices")]
fn main() {
    use horizon_rede_voice::{audio::Options, secret::SecretPacket, session::Session};
    use std::{
        sync::atomic::Ordering,
        time::{Duration, Instant},
    };
    let port = std::env::args().nth(1).unwrap().parse::<u16>().unwrap();
    let protocol = std::env::args().nth(2).unwrap().parse().unwrap();
    let p = SecretPacket {
        protocol,
        secret: [0; 16],
        connection_id: 42u128.to_be_bytes(),
        voice_port: port.into(),
        player_uuid: 42u128.to_be_bytes(),
        codec_id: 0,
        mtu_size: 1024,
        voice_chat_distance: 48.,
        keep_alive: 1000,
        groups_enabled: false,
        voice_host: "127.0.0.1".into(),
        allow_recording: false,
    };
    let session = Session::start(p, "127.0.0.1".into(), Options::default());
    session
        .scene
        .lock()
        .unwrap()
        .players
        .insert(9u128.to_be_bytes(), [-2., 0., 0.]);
    let start = Instant::now();
    while !session.status().contains("espera") {
        assert!(
            start.elapsed() < Duration::from_secs(3),
            "{}",
            session.status()
        );
        std::thread::sleep(Duration::from_millis(5))
    }
    std::thread::sleep(Duration::from_millis(35));
    session.talk.store(true, Ordering::Release);
    std::thread::sleep(Duration::from_millis(300));
    session.talk.store(false, Ordering::Release);
    std::thread::sleep(Duration::from_millis(100));
    println!("PASS worker recognized virtual input and output, PTT toggled");
}
#[cfg(not(feature = "devices"))]
fn main() {
    panic!("requires devices")
}
