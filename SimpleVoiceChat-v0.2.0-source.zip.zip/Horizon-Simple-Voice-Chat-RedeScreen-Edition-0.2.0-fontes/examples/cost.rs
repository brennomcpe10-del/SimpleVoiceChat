// Single active mono speaker, codec + authenticated datagrams, no device or GPU.
use horizon_rede_voice::{
    secret::parse_secret_packet,
    wire::{mic, Transport},
};
use std::time::Instant;
fn main() {
    let mut header = vec![0x13; 32];
    header.extend(24454i32.to_be_bytes());
    header.extend([0; 16]);
    header.push(0);
    header.extend(1024i32.to_be_bytes());
    header.extend(48f64.to_be_bytes());
    header.extend(1000i32.to_be_bytes());
    header.extend([1, 0, 0]);
    let p = parse_secret_packet(&header).unwrap();
    let wire = Transport::new(&p);
    let mut enc = opus::Encoder::new(48000, opus::Channels::Mono, opus::Application::Voip).unwrap();
    let mut dec = opus::Decoder::new(48000, opus::Channels::Mono).unwrap();
    let pcm: [i16; 960] = std::array::from_fn(|i| ((i as f32 * 0.0576).sin() * 5000.) as i16);
    let mut encoded = [0; 1024];
    let mut out = [0; 960];
    let start = Instant::now();
    let mut bytes = 0;
    for seq in 0..3000 {
        let n = enc.encode(&pcm, &mut encoded).unwrap();
        let packet = wire.send(&mic(&encoded[..n], seq, false).unwrap()).unwrap();
        bytes += packet.len();
        let mut reply = vec![255];
        reply.extend(&packet[17..]);
        let clear = wire.receive(&reply).unwrap();
        assert_eq!(
            dec.decode(
                &clear[clear.len() - 9 - n..clear.len() - 9],
                &mut out,
                false
            )
            .unwrap(),
            960
        );
        std::hint::black_box(&out);
    }
    println!(
        "3000 x 20ms frames / 60s media, 1 speaker; elapsed={:.3}s, client_udp={} bytes",
        start.elapsed().as_secs_f64(),
        bytes
    );
}
