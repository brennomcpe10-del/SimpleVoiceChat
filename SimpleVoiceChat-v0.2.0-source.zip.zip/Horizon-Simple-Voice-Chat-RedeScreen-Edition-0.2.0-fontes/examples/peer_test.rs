// Talks only to the synthetic loopback fixture, never to a public voice server.
use horizon_rede_voice::{
    secret::SecretPacket,
    wire::{mic, sound, Handshake, Transport},
};
use std::{net::UdpSocket, time::Duration};
fn main() {
    let port = std::env::args().nth(1).unwrap().parse::<u16>().unwrap();
    let protocol = std::env::args().nth(2).unwrap().parse::<i32>().unwrap();
    let p = SecretPacket {
        protocol,
        secret: [0; 16],
        connection_id: 42u128.to_be_bytes(),
        voice_port: port.into(),
        player_uuid: 42u128.to_be_bytes(),
        codec_id: 0,
        mtu_size: 1024,
        voice_chat_distance: 48.,
        keep_alive: 1000,
        groups_enabled: false,
        voice_host: String::new(),
        allow_recording: false,
    };
    let sock = UdpSocket::bind(("127.0.0.1", 0)).unwrap();
    sock.connect(("127.0.0.1", port)).unwrap();
    sock.set_read_timeout(Some(Duration::from_secs(5))).unwrap();
    let cipher = Transport::new(&p);
    let mut state = Handshake::for_session(&p);
    let send = |body: &[u8]| sock.send(&cipher.send(body).unwrap()).unwrap();
    let read = || {
        let mut b = [0; 2052];
        let n = sock.recv(&mut b).unwrap();
        cipher.receive(&b[..n]).unwrap()
    };
    send(&state.retry().unwrap());
    send(&state.control(&read()).unwrap());
    state.control(&read());
    assert!(state.connected);
    send(&state.control(&read()).unwrap());
    let mut enc = opus::Encoder::new(48000, opus::Channels::Mono, opus::Application::Voip).unwrap();
    let pcm: [i16; 960] = std::array::from_fn(|i| ((i as f32 * 0.0576).sin() * 5000.) as i16);
    let mut encoded = [0; 1024];
    let n = enc.encode(&pcm, &mut encoded).unwrap();
    send(&mic(&encoded[..n], 37, false).unwrap());
    let bytes = read();
    let s = sound(&bytes).unwrap();
    assert_eq!(s.sender, 9u128.to_be_bytes());
    assert_eq!(s.distance, 48.);
    assert_eq!(s.seq, 37);
    let mut dec = opus::Decoder::new(48000, opus::Channels::Mono).unwrap();
    let mut out = [0; 960];
    assert_eq!(dec.decode(s.opus, &mut out, false).unwrap(), 960);
    assert!(out.iter().any(|x| x.unsigned_abs() > 500));
    println!("PASS Rust UDP, Opus 48 kHz / 960 samples, non-silent decoded output");
}
