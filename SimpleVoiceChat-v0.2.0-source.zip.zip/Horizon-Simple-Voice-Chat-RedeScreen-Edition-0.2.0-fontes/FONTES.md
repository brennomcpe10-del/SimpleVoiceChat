# Fontes e revisões

O ZIP recebido tinha SHA-256 `1300707c5ac51f4938761191600ea117ff83c93fef3bc676c2b3bf2bdc6122e3`. Ele forneceu o leitor inicial do SecretPacket. A integração, o transporte, o áudio e os testes de interoperabilidade foram desenvolvidos nesta entrega. A derivação Debug do segredo foi removida para impedir a exposição por formatação de depuração.

| Projeto | Revisão examinada | Aplicação |
|---|---|---|
| Horizon | [a4873dec](https://github.com/horizon-rust/horizon/tree/a4873dec445a5f619bc2200069f65a76dc170a0c) | Base do cliente que compilou. O registro inclui o Minecraft 26.3. |
| Native Mod Template | [cc8ce2d8](https://github.com/horizon-rust/horizon-native-mod-template/tree/cc8ce2d896782099abfa9f0abf26fa80c9e4bddb) | Estrutura e fixação da revisão. O template aponta para outro commit do Horizon, ba6344a5. |
| Horizon Mods | [d933c333](https://github.com/horizon-rust/horizon-mods/tree/d933c333e6e705fdb7f682c2039d994d7f4fe9f4) | Registro oficial e padrão de hooks dos mods nativos. |
| Horizon Mixins | [a2af5c0d](https://github.com/horizon-rust/horizon-mixins/tree/a2af5c0dd4117d51ecd70066ba7a00b4a2c10dab) | CLI real usada para planejar o manifesto do protótipo e a tentativa com dependências. |
| Simple Voice Chat, 26.3 | [90e49b73](https://github.com/henkelmax/simple-voice-chat/tree/90e49b73d6a43f201b8ef854698af70642986001) | 2.7.0-pre1+26.3, protocolo 21. |
| Simple Voice Chat, 2.6.x/26.3 | [2e561980](https://github.com/henkelmax/simple-voice-chat/tree/2e56198016e02fd99139d37f382b7155c5bd63f5) | 2.6.28+26.3 no fonte, protocolo 20. |
| Plugin Bukkit publicado | [2.6.27 no Modrinth](https://modrinth.com/plugin/simple-voice-chat/version/3Br8wxJY) | O JAR publicado declara compatibilidade 20. O teste conferiu o SHA-512 fornecido e usou as classes compiladas de mensagem, criptografia e áudio diretamente. |

Os formatos são baseados nas classes RequestSecretPacket, SecretPacket, NetworkMessage, ClientNetworkMessage, Secret, AuthenticatePacket, AuthenticateAckPacket, ConnectionCheckPacket, ConnectionCheckAckPacket, MicPacket, PlayerSoundPacket, GroupSoundPacket, LocationSoundPacket, KeepAlivePacket, PingPacket, PlayerState e UpdateStatePacket das árvores acima. A lógica de repetição e de keep-alive foi comparada com ClientVoicechatConnection e Server. As classes de referência para os testes são lidas dos checkouts oficiais. O JAR e as classes Java do Simple Voice Chat não são distribuídos.

## Motivo do patch de cliente

O hook `native_net_send_to_server` do Horizon envia um envelope em `horizon:mod_net` e depende de o servidor anunciar suporte a esse envelope. O Simple Voice Chat espera os canais Minecraft diretamente. O cliente já encaminha custom payloads desconhecidos do leitor TCP ao loop de jogo. O patch trata ali os canais de voz, usa o perfil da sessão, associa o worker à conexão remota e mantém o caminho original para os demais pacotes.

O formato oficial permite módulos Rust e crates, mas o planejador só aceita dependências do lockfile original. Na árvore examinada, o manifesto que pedia AES-GCM e Opus foi recusado com E_CRATE_DEPENDENCY para aes-gcm; opus também não consta no lock original. O manifesto recebido foi recusado com E_REVISION. A cópia do cliente inclui as dependências no seu próprio lockfile e expõe as configurações pelos hooks nativos. Não empacotamos as dependências como se o launcher original pudesse instalá-las.

As licenças e avisos do Horizon estão em `horizon/LICENSE` e `horizon/THIRD_PARTY_NOTICES.md`. As ferramentas de desenvolvimento Java que já pertencem ao projeto Horizon não passam a fazer parte do cliente de voz. O código Rust obtém Opus através do Cargo e usa CPAL para o áudio e RustCrypto AES-GCM para o transporte.
