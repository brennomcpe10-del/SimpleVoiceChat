"""Download the pinned libraries for the Java reference peer (test machine only)."""
import hashlib
import sys
import urllib.request
from pathlib import Path
HASHES={
    'buffer':'0eea4e8666a9636a28722661d8ba5fa8564477e75fec6dd2ff3e324e361f8b3c',
    'codec':'4abd215fd1ed7ce86509d169cc9cbede5042176c265a79b3b70602b017226c3f',
    'common':'65cce901ecf0f9d6591cc7750772614ab401a84415dc9aec9da4d046f0f9a77c',
    'resolver':'3170c225972c18b6850d28add60db15bb28d83c4e3d5b686ca220e0bd7273c8a',
    'transport':'ab3751e717daef9c8d91e4d74728a48730bd8530b72e2466b222b2ea3fb07db9',
}
root=Path(sys.argv[1])
root.mkdir(parents=True,exist_ok=True)
for name,digest in HASHES.items():
    url=f'https://repo.maven.apache.org/maven2/io/netty/netty-{name}/4.1.118.Final/netty-{name}-4.1.118.Final.jar'
    with urllib.request.urlopen(url,timeout=60) as src:
        data=src.read(2_000_001)
    if hashlib.sha256(data).hexdigest()!=digest:raise RuntimeError(f'checksum failed for {name}')
    (root/f'netty-{name}.jar').write_bytes(data)
