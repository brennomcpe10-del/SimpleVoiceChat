"""Run AFTER cargo build --release --example cost. Linux, measured process only."""
import os,resource,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=os.fork()
if p==0:os.execl(root/'target/release/examples/cost','cost')
_,status,ru=os.wait4(p,0)
print(f'CPU user={ru.ru_utime:.3f}s system={ru.ru_stime:.3f}s max_RSS={ru.ru_maxrss} KiB')
sys.exit(os.waitstatus_to_exitcode(status))
