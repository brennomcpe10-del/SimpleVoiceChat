# Horizon Simple Voice Chat — RedeScreen Edition

**0.2.0 · entrega de código-fonte para homologação · 31/10/2026**

A voz passou pelo cliente de rede do Horizon e pelos dois protocolos do Simple Voice Chat em um teste local com áudio virtual. Não há uma instalação aprovada para jogar no RedeScreen. O executável Windows foi compilado e inspecionado, mas não foi executado em Windows. O ZIP contém o código e os resultados para continuar desse ponto.

| Arquivo ou pasta | Conteúdo |
|---|---|
| `horizon/` | Árvore do Horizon na revisão fixada, já com a integração e o núcleo de voz aplicados. |
| `src/`, `Cargo.toml`, `Cargo.lock` | Núcleo Rust independente. Inclui áudio, Opus, enquadramento de datagramas, AES-GCM e sessão. |
| `integration/` | Código da ponte com o jogo e cliente de homologação TCP/UDP. As mesmas fontes estão no local de compilação em `horizon/`. |
| `tests/`, `examples/`, `tools/` | Testes unitários, par Java local de referência, dispositivos virtuais e medição de custo. |
| `TESTES.md`, `logs/` | Resultado de cada teste, o que ele comprova e o que ainda exige hardware ou servidor real. |
| `WINDOWS.md` | Situação do download, procedimento de instalação isolada para uma futura candidata, teste com duas pessoas e desinstalação. |
| `FONTES.md`, `compatibility.json` | Revisões, classes usadas como referência e decisão sobre o formato de distribuição. |
| `.github/workflows/windows.yml` | Compilação e qualificação manual em um runner Windows. Foi preparada para um repositório dedicado e não foi executada. |
| `SHA256SUMS.txt` | SHA-256 de cada arquivo do pacote, exceto a própria lista. |

## Controles implementados

**V** abre a página de voz no menu nativo do Horizon. **Alt esquerdo** é o push-to-talk inicial. Os dois atalhos podem ser alterados na página do mod. Os botões alternam entrada, saída, push-to-talk ou microfone aberto e volume em passos de 25%. A captura para transmissão depende de o jogo estar em foco e com a tela de jogo aberta. Um rótulo no HUD informa espera, autenticação, conexão e estado do microfone. É possível receber voz mesmo quando a entrada de áudio não abre.

O cliente usa as posições e a orientação do jogo para vozes de jogadores e sons de localização. Também decodifica som estático de grupo. O volume de proximidade cai até o raio indicado no pacote e o som é distribuído entre esquerda e direita. As coordenadas são atualizadas a cada tick. O teto é de 32 canais simultâneos, três quadros de entrada pendentes e quatro quadros de saída por canal. O quadro Opus tem 20 ms, mono, a 48 kHz. O dispositivo pode usar outra frequência de PCM e o cliente converte para a frequência do protocolo.

## Conexão

A integração usa a sessão multiplayer do próprio Horizon depois da entrada no estado de jogo. Registra os canais do Minecraft, solicita o segredo e confere o UUID da resposta contra o perfil recebido nessa sessão. O servidor compara a versão enviada e só responde com um segredo compatível. Em ausência de resposta, a sequência limitada é 20, 21 e 20, em intervalos de seis segundos. Uma versão incompatível pode produzir o aviso normal do servidor. A opção Reconectar permite tentar novamente.

O protocolo 20 usa o UUID do jogador no envelope e na autenticação cifrada. O 21 usa um ID de conexão separado e exige devolver o desafio de 16 bytes. O cliente responde a keep-alive e ping, descarta quadros inválidos e guarda o segredo apenas em memória, vinculado à sessão de jogo. Trocar de servidor, entrar em reconfiguração ou sair descarta a sessão. A perda de UDP aciona uma nova tentativa com espera. O servidor pode substituir o segredo pela sessão Minecraft existente. O cliente não precisa de Java, Fabric, Forge ou NeoForge.

O escopo é conversa e audição. Criar ou administrar grupos, configurar volumes por categoria e negociar extensões específicas de plugins não foi implementado. Uma categoria enviada pelo servidor é validada e o áudio usa o volume global. A versão e a configuração reais do RedeScreen ainda não foram verificadas.

## Reproduzir em uma máquina de desenvolvimento

A máquina de quem joga não precisa executar estas etapas. Um mantenedor pode usar Rust 1.99.1 e as dependências de compilação do Horizon e do Opus. O Cargo verifica os pacotes de registro contra os lockfiles. Os comandos abaixo partem da raiz extraída.

```sh
cargo test --locked --features devices
cargo build --manifest-path horizon/Cargo.toml --locked -p horizon-client --bin horizon-client --profile fast
```

No Linux, o backend de áudio usa ALSA. A compilação padrão do jogo também precisa de libudev. A compilação e os testes do relatório usaram Rust 1.99.1. Em Windows, o workflow usa Visual Studio Build Tools, CMake e Rust no runner. O JDK serve apenas para os testes com as classes Java de referência. Veja `TESTES.md` para reproduzir o ensaio de voz e `WINDOWS.md` para a etapa em jogo.
