// Development-only loopback server and client. No Mojang account or game assets.
use horizon_client::net::{Event, Session as GameSession};
use horizon_protocol::{
    connection::Connection,
    packets::{configuration as cfg, handshake, login, play, Empty},
    text::Language,
};
use horizon_rede_voice::{audio::Options, secret::parse_version, session::Session};
use std::{
    net::TcpListener,
    path::PathBuf,
    sync::{atomic::Ordering, Arc},
    thread,
    time::{Duration, Instant},
};

fn main() {
    let args: Vec<_> = std::env::args().collect();
    let udp_port = args[1].parse::<u16>().unwrap();
    let protocol = args[2].parse::<i32>().unwrap();
    let listener = TcpListener::bind(("127.0.0.1", 0)).unwrap();
    let address = listener.local_addr().unwrap().to_string();
    let game = GameSession::connect(
        &address,
        "VoiceTest",
        None,
        cfg::ClientInformation::new(4),
        Arc::new(Language::new()),
        PathBuf::new(),
    );
    let (stream, _) = listener.accept().unwrap();
    stream
        .set_read_timeout(Some(Duration::from_secs(4)))
        .unwrap();
    let mut server = Connection::from_stream(stream).unwrap();
    let (id, bytes) = server.recv().unwrap();
    assert!(matches!(
        handshake::Serverbound::decode(id, &bytes),
        Ok(handshake::Serverbound::Intention(_))
    ));
    let (id, bytes) = server.recv().unwrap();
    assert!(matches!(
        login::Serverbound::decode(id, &bytes),
        Ok(login::Serverbound::Hello(_))
    ));
    let uuid = 42u128;
    server
        .send(
            &login::Clientbound::LoginFinished(login::LoginFinished {
                profile: login::GameProfile {
                    uuid,
                    name: "VoiceTest".into(),
                    properties: vec![],
                },
                session: 1,
            })
            .encode(),
        )
        .unwrap();
    let (id, b) = server.recv().unwrap();
    assert!(matches!(
        login::Serverbound::decode(id, &b),
        Ok(login::Serverbound::LoginAcknowledged(_))
    ));
    server.recv().unwrap();
    server.recv().unwrap(); // client settings and brand
    server
        .send(&cfg::Clientbound::FinishConfiguration(Empty).encode())
        .unwrap();
    let (id, b) = server.recv().unwrap();
    assert!(matches!(
        cfg::Serverbound::decode(id, &b),
        Ok(cfg::Serverbound::FinishConfiguration(_))
    ));
    let deadline = Instant::now() + Duration::from_secs(4);
    while !game
        .poll()
        .iter()
        .any(|e| matches!(e, Event::Joined { uuid: 42, .. }))
    {
        assert!(Instant::now() < deadline);
        thread::sleep(Duration::from_millis(2))
    }
    game.send(play::Serverbound::CustomPayload(cfg::CustomPayload {
        channel: "voicechat:request_secret".into(),
        data: protocol.to_be_bytes().to_vec(),
    }));
    let (id, b) = server.recv().unwrap();
    let play::Serverbound::CustomPayload(req) = play::Serverbound::decode(id, &b).unwrap() else {
        panic!("custom payload missing")
    };
    assert_eq!(req.channel, "voicechat:request_secret");
    assert_eq!(req.data, protocol.to_be_bytes());
    let mut raw = vec![0; 16];
    if protocol == 21 {
        raw.extend(42u128.to_be_bytes())
    }
    raw.extend(i32::from(udp_port).to_be_bytes());
    raw.extend(uuid.to_be_bytes());
    raw.push(0);
    raw.extend(1024i32.to_be_bytes());
    raw.extend(48f64.to_be_bytes());
    raw.extend(1000i32.to_be_bytes());
    raw.extend([0, 0, 0]);
    server
        .send(
            &play::Clientbound::CustomPayload(cfg::CustomPayload {
                channel: "voicechat:secret".into(),
                data: raw,
            })
            .encode(),
        )
        .unwrap();
    let secret = 'wait: loop {
        for e in game.poll() {
            if let Event::Packet(p) = e {
                if let play::Clientbound::CustomPayload(data) = *p {
                    assert_eq!(data.channel, "voicechat:secret");
                    let p = parse_version(&data.data, protocol).unwrap();
                    assert_eq!(p.player_uuid, uuid.to_be_bytes());
                    break 'wait p;
                }
            }
        }
        assert!(Instant::now() < deadline);
        thread::sleep(Duration::from_millis(2));
    };
    let s = Session::start(secret, address, Options::default());
    s.scene
        .lock()
        .unwrap()
        .players
        .insert(9u128.to_be_bytes(), [-2., 0., 0.]);
    while !s.status().contains("espera") {
        assert!(Instant::now() < deadline, "{}", s.status());
        thread::sleep(Duration::from_millis(2))
    }
    thread::sleep(Duration::from_millis(40));
    s.talk.store(true, Ordering::Release);
    thread::sleep(Duration::from_millis(240));
    s.talk.store(false, Ordering::Release);
    thread::sleep(Duration::from_millis(80));
    println!("PASS Horizon TCP login/configuration, request/secret, account UUID, UDP and virtual audio (compat {protocol})");
}
