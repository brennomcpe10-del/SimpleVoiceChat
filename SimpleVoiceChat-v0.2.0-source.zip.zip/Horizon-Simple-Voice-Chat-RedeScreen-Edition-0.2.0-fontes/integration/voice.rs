// Kept on Remote: changing server or closing the game drops the UDP session.
use super::{native_hooks::NativeMod, Game};
use horizon_protocol::packets::{configuration::CustomPayload, play::Serverbound};
use horizon_rede_voice::{
    audio::Options,
    secret::{parse_version, SecretPacket},
    session::Session,
};
use std::{
    sync::atomic::Ordering,
    time::{Duration, Instant},
};
const ID: &str = "redescreen_voice";
#[derive(Default)]
pub(super) struct Voice {
    session: Option<Session>,
    retry: Option<Instant>,
    attempts: u8,
    pressed: bool,
    saved: Option<SecretPacket>,
    protocol: i32,
    forced: (bool, bool),
    reported: Option<(bool, bool)>,
}
impl Game<'_> {
    fn voice_options(&self) -> Options {
        let read = |key: &str| {
            self.settings
                .mods
                .keys
                .get(ID)
                .and_then(|k| k.get(key))
                .cloned()
        };
        Options {
            input: read("input"),
            output: read("output"),
            open: read("mode").as_deref() == Some("open"),
            volume: read("volume")
                .and_then(|s| s.parse::<f32>().ok())
                .filter(|x| x.is_finite())
                .or(Some(1.)),
        }
    }
    pub(super) fn voice_list(&self, mods: &mut Vec<NativeMod>) {
        mods.push(NativeMod {
            id: ID.into(),
            title: "Horizon Simple Voice Chat — RedeScreen Edition".into(),
            description: "Voz por proximidade · protocolos 20 e 21".into(),
            keys: vec![
                [
                    "menu".into(),
                    "Configurações de voz".into(),
                    "key.keyboard.v".into(),
                ],
                [
                    "ptt".into(),
                    "Aperte para falar".into(),
                    "key.keyboard.left.alt".into(),
                ],
            ],
        });
    }
    pub(super) fn voice_buttons(&self, id: &str, buttons: &mut Vec<String>) {
        if id != ID {
            return;
        }
        let o = self.voice_options();
        buttons.extend([
            format!(
                "Modo: {}",
                if o.open {
                    "Microfone aberto"
                } else {
                    "Push-to-talk"
                }
            ),
            format!("Volume: {:.0}%", 100. * o.volume.unwrap_or(1.)),
            format!("Entrada: {}", o.input.as_deref().unwrap_or("Padrão")),
            format!("Saída: {}", o.output.as_deref().unwrap_or("Padrão")),
            "Reconectar".into(),
        ]);
    }
    pub(super) fn voice_click(&mut self, id: &str, button: usize) {
        if id != ID {
            return;
        }
        let o = self.voice_options();
        let (key, val) = match button {
            0 => ("mode", Some(if o.open { "ptt" } else { "open" }.to_owned())),
            1 => (
                "volume",
                Some(((o.volume.unwrap_or(1.) + 0.25) % 1.25).to_string()),
            ),
            2 | 3 => {
                let input = button == 2;
                let names = horizon_rede_voice::audio::device_names(input);
                let selected = if input { o.input } else { o.output };
                let val = match selected {
                    None => names.first().cloned(),
                    Some(s) => names
                        .iter()
                        .position(|n| n == &s)
                        .and_then(|i| names.get(i + 1))
                        .cloned(),
                };
                (if input { "input" } else { "output" }, val)
            }
            4 => ("retry", None),
            _ => return,
        };
        if button != 4 {
            let opts = self.settings.mods.keys.entry(ID.into()).or_default();
            if let Some(v) = val {
                opts.insert(key.into(), v);
            } else {
                opts.remove(key);
            }
        }
        let opts = self.voice_options();
        if let Some(r) = &mut self.remote {
            if button == 4 {
                r.voice.session = None;
                r.voice.retry = None;
                r.voice.attempts = 0
            } else if let Some(s) = &r.voice.session {
                if let Ok(mut o) = s.options.lock() {
                    *o = opts
                }
            }
        }
    }
    pub(super) fn voice_key(&mut self, key: &str, down: bool) {
        if !self.native_on(ID) {
            return;
        }
        let playing = self.native_playing();
        if key == self.native_mod_key(ID, "ptt", "key.keyboard.left.alt") {
            if let Some(r) = &mut self.remote {
                r.voice.pressed = down && playing && self.focused
            }
        }
        if down && playing && key == self.native_mod_key(ID, "menu", "key.keyboard.v") {
            if let Some(i) = self.settings.mods.installed.iter().position(|m| m.id == ID) {
                self.capture(false);
                self.native_settings_refresh(i);
                self.open_options_at(false, horizon_client::options_ui::Page::NativeMod(i));
                self.options_to_game = true
            }
        }
    }
    pub(super) fn voice_status(&self) -> Option<&'static str> {
        if !self.native_on(ID) {
            return None;
        }
        let r = self.remote.as_ref()?;
        Some(
            r.voice
                .session
                .as_ref()
                .map(Session::status)
                .unwrap_or(if r.voice.attempts < 3 {
                    "Aguardando servidor de voz"
                } else {
                    "Sem resposta do servidor de voz"
                }),
        )
    }
    pub(super) fn voice_tick(&mut self) {
        let opts = self.voice_options();
        let enabled = self.native_on(ID);
        let talking = self.focused && self.native_playing();
        let Some(r) = self.remote.as_mut() else {
            return;
        };
        if !enabled || !r.logged_in || r.reconfiguring.is_some() {
            r.voice = Voice::default();
            return;
        }
        if !talking {
            r.voice.pressed = false
        }
        if let Some(s) = &r.voice.session {
            if s.ended() {
                r.voice.session = None;
                r.voice.attempts = 0;
                r.voice.retry = Some(Instant::now() + Duration::from_secs(4));
                return;
            }
            let open = self
                .settings
                .mods
                .keys
                .get(ID)
                .and_then(|k| k.get("mode"))
                .is_some_and(|m| m == "open");
            s.deaf.store(r.voice.forced.1, Ordering::Release);
            s.talk.store(
                talking && !r.voice.forced.0 && !r.voice.forced.1 && (r.voice.pressed || open),
                Ordering::Release,
            );
            if let Some(p) = &self.player {
                if let Ok(mut scene) = s.scene.try_lock() {
                    scene.listener = [p.position.x, p.position.y, p.position.z];
                    scene.yaw = self.yaw;
                    scene.players.clear();
                    r.voice_positions(&mut scene.players);
                }
            }
            if let Some((muted, disabled)) = s.device_state() {
                if r.voice.reported != Some((muted, disabled)) {
                    r.voice.reported = Some((muted, disabled));
                    let data = if r.voice.protocol == 20 {
                        vec![disabled as u8]
                    } else {
                        vec![muted as u8, disabled as u8]
                    };
                    let channel = if r.voice.protocol == 20 {
                        "voicechat:update_state"
                    } else {
                        "voicechat:client_state"
                    };
                    self.send(Serverbound::CustomPayload(CustomPayload {
                        channel: channel.into(),
                        data,
                    }));
                }
            }
        } else if r.joined && r.voice.retry.is_none_or(|t| Instant::now() >= t) {
            if let Some(p) = &r.voice.saved {
                r.voice.session = Some(Session::start(p.clone(), r.session.address.clone(), opts));
                return;
            }
            if r.voice.attempts >= 3 {
                return;
            }
            r.voice.protocol = if r.voice.attempts % 2 == 0 { 20 } else { 21 };
            let request = r.voice.protocol.to_be_bytes();
            r.voice.attempts += 1;
            r.voice.retry = Some(Instant::now() + Duration::from_secs(6));
            self.send(Serverbound::CustomPayload(CustomPayload {
                channel: "minecraft:register".into(),
                data: b"voicechat:secret\0voicechat:state\0voicechat:states".to_vec(),
            }));
            self.send(Serverbound::CustomPayload(CustomPayload {
                channel: "voicechat:request_secret".into(),
                data: request.to_vec(),
            }));
        }
    }
    pub(super) fn voice_state(&mut self, bytes: &[u8], list: bool) {
        let Some(r) = self.remote.as_mut() else {
            return;
        };
        if r.voice.protocol == 21 {
            if let Ok(Some(flags)) =
                horizon_rede_voice::wire::own_restrictions(bytes, list, r.profile().to_be_bytes())
            {
                r.voice.forced = flags;
                if let Some(s) = &r.voice.session {
                    s.deaf.store(flags.1, Ordering::Release);
                    if flags.0 || flags.1 {
                        s.talk.store(false, Ordering::Release)
                    }
                }
            }
        }
    }
    pub(super) fn voice_secret(&mut self, bytes: &[u8]) {
        if !self.native_on(ID) {
            return;
        }
        let opts = self.voice_options();
        let Some(r) = self.remote.as_mut() else {
            return;
        };
        if r.reconfiguring.is_some()
            || !r.joined
            || (r.voice.attempts == 0 && r.voice.saved.is_none())
        {
            return;
        }
        let Ok(p) = parse_version(bytes, r.voice.protocol) else {
            return;
        };
        if p.player_uuid != r.profile().to_be_bytes() {
            return;
        }
        if r.voice.saved.as_ref() == Some(&p) && r.voice.session.is_some() {
            return;
        }
        r.voice.reported = None;
        r.voice.saved = Some(p.clone());
        r.voice.session = Some(Session::start(p, r.session.address.clone(), opts));
    }
}
