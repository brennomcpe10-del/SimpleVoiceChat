import de.maxhenkel.voicechat.util.FriendlyByteBuf;
import de.maxhenkel.voicechat.voice.common.*;
class Encoder {
    static byte[] encode(int type,Packet<?> packet) throws Exception {
        FriendlyByteBuf body=new FriendlyByteBuf();body.writeByte(type);packet.toBytes(body);
        byte[] bytes=new byte[body.readableBytes()];body.readBytes(bytes);body.release();
        return Peer.key.encrypt(bytes);
    }
}
