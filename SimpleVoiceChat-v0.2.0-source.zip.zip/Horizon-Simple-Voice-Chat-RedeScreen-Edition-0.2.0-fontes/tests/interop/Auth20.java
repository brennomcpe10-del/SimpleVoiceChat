import de.maxhenkel.voicechat.util.FriendlyByteBuf;
import de.maxhenkel.voicechat.voice.common.*;
class Auth {
    static void exchange(java.net.DatagramSocket s) throws Exception {
        FriendlyByteBuf in=Peer.recv(s);if(in.readByte()!=5)throw new Exception("auth");
        AuthenticatePacket auth=new AuthenticatePacket().fromBytes(in);
        if(!auth.getPlayerUUID().equals(Peer.id)||!auth.getSecret().equals(Peer.key)||in.isReadable())throw new Exception("legacy auth");in.release();
        Peer.send(s,6,new AuthenticateAckPacket());
        in=Peer.recv(s);if(in.readByte()!=9 || in.isReadable())throw new Exception("legacy check");in.release();
    }
}
