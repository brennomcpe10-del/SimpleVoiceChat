import de.maxhenkel.voicechat.util.FriendlyByteBuf;
import de.maxhenkel.voicechat.voice.common.*;
import java.util.Arrays;
class Auth {
    static void exchange(java.net.DatagramSocket s) throws Exception {
        FriendlyByteBuf in=Peer.recv(s);if(in.readByte()!=5 || in.isReadable())throw new Exception("auth");in.release();
        byte[] challenge=new byte[16];new java.security.SecureRandom().nextBytes(challenge);
        Peer.send(s,6,new AuthenticateAckPacket(challenge));
        in=Peer.recv(s);if(in.readByte()!=9 || !Arrays.equals(new ConnectionCheckPacket().fromBytes(in).getNonce(),challenge))throw new Exception("challenge");in.release();
    }
}
