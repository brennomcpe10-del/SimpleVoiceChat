import de.maxhenkel.voicechat.voice.common.*;
class Encoder {
    static byte[] encode(int type,Packet<?> packet) throws Exception {
        // The registered type, serialization and encryption are all the published plugin's.
        return new NetworkMessage(packet).write(Peer.key);
    }
}
