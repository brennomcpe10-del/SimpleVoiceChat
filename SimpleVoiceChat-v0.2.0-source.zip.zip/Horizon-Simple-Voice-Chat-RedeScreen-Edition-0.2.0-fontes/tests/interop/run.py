"""Usage: python run.py /path/to/pinned/simple-voice-chat /path/to/netty-jar-directory
JDK 17+ is needed only for this developer test."""
import hashlib, math, os, struct, subprocess, sys, tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[2]
repo=Path(sys.argv[1]).resolve()
revision=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
protocol={'90e49b73d6a43f201b8ef854698af70642986001':21,'2e56198016e02fd99139d37f382b7155c5bd63f5':20}[revision]
cp=os.pathsep.join(str(p) for p in Path(sys.argv[2]).resolve().glob('netty-*.jar') if p.is_file())
base=repo/'bukkit/src/main/java/de/maxhenkel/voicechat'
sources=[base/'util/FriendlyByteBuf.java']
sources += [base/'voice/common'/f'{s}.java' for s in 'Secret Packet AuthenticatePacket MicPacket AuthenticateAckPacket ConnectionCheckPacket ConnectionCheckAckPacket KeepAlivePacket PlayerSoundPacket SoundPacket AudioUtils'.split()]
with tempfile.TemporaryDirectory() as t:
    path=Path(t)
    # Compile-time adapters for references outside the selected upstream classes.
    stubs={
    'Nullable.java':'package javax.annotation; public @interface Nullable {}',
    'NetworkMessage.java':'package de.maxhenkel.voicechat.voice.common; public class NetworkMessage {static final int NONCE_SIZE_BYTES=16;}',
    'Utils.java':'package de.maxhenkel.voicechat.voice.common; public class Utils { public static byte[] generateSecureRandomBytes(int n) {byte[] b=new byte[n]; new java.security.SecureRandom().nextBytes(b); return b;} }'}
    encoder='EncoderSource.java'
    if '--plugin' in sys.argv:
        assert protocol==20
        jar=Path(sys.argv[sys.argv.index('--plugin')+1]).resolve()
        assert hashlib.sha512(jar.read_bytes()).hexdigest()=='9d55c64e79289da87b6c51295124477b4061f5820bd68370c1f6b82137c7ca19d5db7bc05828f12091f23c6ddf1b328b8c5018d4df85fa7c3ddacc6f8f114abe'
        cp=str(jar)+os.pathsep+cp
        sources=[]
        encoder='EncoderPublished.java'
    else:
        for f,s in stubs.items():(path/f).write_text(s)
    subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-cp',cp,'-d',t,*sources,*path.glob('*.java'),Path(__file__).with_name('Peer.java'),Path(__file__).with_name(encoder),Path(__file__).with_name(f'Auth{protocol}.java')],check=True)
    virtual='--virtual' in sys.argv[3:]
    example='virtual_session' if virtual else 'peer_test'
    env=dict(os.environ)
    if virtual:
        pcm=path/'input.raw'
        pcm.write_bytes(b''.join(struct.pack('<h',int(9000*math.sin(i*.0576))) for i in range(48000))*16)
        config=path/'asound.conf'
        config.write_text(f'''<confdir:alsa.conf>
pcm.voiceinp {{ type file slave.pcm "null" file "/dev/null" infile "{pcm}" format "raw" }}
pcm.voiceout {{ type file slave.pcm "null" file "{path}/output.raw" format "raw" }}
pcm.!default {{ type asym playback.pcm "voiceout" capture.pcm "voiceinp" }}
''')
        env['ALSA_CONFIG_PATH']=str(config)
    if '--horizon' in sys.argv:
        assert virtual
        tree=Path(sys.argv[sys.argv.index('--horizon')+1]).resolve()
        subprocess.run(['cargo','build','--locked','--no-default-features','--features','audio',
                        '-p','horizon-client','--example','voice_login'],cwd=tree,check=True)
        binary=tree/'target/debug/examples/voice_login'
    else:
        subprocess.run(['cargo','build','--locked','--features','devices','--example',example],cwd=root,check=True)
        binary=root/'target/debug/examples'/example
    if os.name=='nt':binary=binary.with_suffix('.exe')
    with subprocess.Popen(['java','-cp',t+os.pathsep+cp,'Peer',*(['virtual'] if virtual else [])],stdout=subprocess.PIPE,text=True) as peer:
        port=int(peer.stdout.readline())
        subprocess.run([binary,str(port),str(protocol)],check=True,timeout=10,env=env)
        print(peer.stdout.read(),end='')
        if peer.wait(timeout=8):raise RuntimeError('reference peer failed')
    if virtual:
        # CPAL prefers stereo f32, compare output energy on the actual file-backed sink.
        energy=[0.,0.]
        with (path/'output.raw').open('rb') as f:
            while block:=f.read(65536):
                for left,right in struct.iter_unpack('<ff',block):
                    energy[0]+=left*left;energy[1]+=right*right
        assert energy[1]>1 and energy[1]>4*energy[0],energy
        print('PASS positional virtual output energy L/R:',energy)
