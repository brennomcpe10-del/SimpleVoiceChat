import java.net.*;
import java.util.*;
import de.maxhenkel.voicechat.util.FriendlyByteBuf;
import de.maxhenkel.voicechat.voice.common.*;
import io.netty.buffer.Unpooled;

// Local test fixture. The byte buffer, cryptography and packet classes are built from upstream.
public class Peer {
    static final UUID id = new UUID(0,42);
    static final Secret key = Secret.fromBytes(new byte[16]); // synthetic, never used by the game
    static SocketAddress client;
    static FriendlyByteBuf recv(DatagramSocket s) throws Exception {
        byte[] b=new byte[2052]; DatagramPacket d=new DatagramPacket(b,b.length); s.receive(d);
        client=d.getSocketAddress();
        FriendlyByteBuf in=new FriendlyByteBuf(Unpooled.wrappedBuffer(b,0,d.getLength()));
        if(in.readUnsignedByte()!=255 || !in.readUUID().equals(id))throw new Exception("client envelope");
        byte[] p=key.decrypt(in.readByteArray(2048));
        if(in.isReadable())throw new Exception("trailing bytes"); in.release();
        return new FriendlyByteBuf(Unpooled.wrappedBuffer(p));
    }
    static void send(DatagramSocket s,int type,Packet<?> packet) throws Exception {
        FriendlyByteBuf out=new FriendlyByteBuf();out.writeByte(255);out.writeByteArray(Encoder.encode(type,packet));
        byte[] wire=new byte[out.readableBytes()];out.readBytes(wire);out.release();
        s.send(new DatagramPacket(wire,wire.length,client));
    }
    public static void main(String[] args) throws Exception {
        try(DatagramSocket s=new DatagramSocket(0,InetAddress.getByName("127.0.0.1"))) {
            s.setSoTimeout(5000);
            System.out.println(s.getLocalPort());System.out.flush();
            Auth.exchange(s); FriendlyByteBuf in;
            send(s,10,new ConnectionCheckAckPacket());
            send(s,8,new KeepAlivePacket());
            in=recv(s);if(in.readByte()!=8)throw new Exception("keepalive");in.release();
            in=recv(s);if(in.readByte()!=1)throw new Exception("mic");
            MicPacket mic=new MicPacket().fromBytes(in);in.release();
            if(mic.isWhispering() || mic.getSequenceNumber()!=(args.length==0?37:0) || mic.getData().length==0)throw new Exception("mic fields");
            send(s,2,new PlayerSoundPacket(new UUID(0,7),new UUID(0,9),mic.getData(),37,false,48F,"test"));
            if(args.length>0){
                boolean end=false;
                while(!end){
                    in=recv(s);int type=in.readUnsignedByte();
                    if(type==1){MicPacket m=new MicPacket().fromBytes(in);end=m.getData().length==0;}
                    in.release();
                }
                System.out.println("PASS PTT terminator");
            }
            System.out.println("PASS official AES, auth check, keepalive, MicPacket and PlayerSoundPacket");
        }
    }
}
