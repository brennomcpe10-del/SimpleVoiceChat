use horizon_rede_voice::{
    secret::parse_version,
    wire::{own_restrictions, sound, Handshake, Transport},
};
fn fixture(v: i32) -> Vec<u8> {
    let mut data = vec![0x78; 16];
    if v == 21 {
        data.extend([0x64; 16])
    }
    data.extend(24454i32.to_be_bytes());
    data.extend([0x32; 16]);
    data.push(0);
    data.extend(1024i32.to_be_bytes());
    data.extend(48f64.to_be_bytes());
    data.extend(1000i32.to_be_bytes());
    data.extend([1, 0, 0]);
    data
}
#[test]
fn secret_version_and_truncation() {
    for v in [20, 21] {
        let f = fixture(v);
        let p = parse_version(&f, v).unwrap();
        assert_eq!(
            p.connection_id,
            if v == 20 { p.player_uuid } else { [0x64; 16] }
        );
        assert!(parse_version(&f, 41 - v).is_err());
        for end in 0..f.len() {
            assert!(parse_version(&f[..end], v).is_err())
        }
    }
}
#[test]
fn rejects_forgery_and_oversize() {
    let p = parse_version(&fixture(21), 21).unwrap();
    let c = Transport::new(&p);
    let client = c.send(&[8]).unwrap();
    let mut upstream = vec![255];
    upstream.extend_from_slice(&client[17..]);
    assert_eq!(c.receive(&upstream).unwrap(), vec![8]);
    assert_ne!(client, c.send(&[8]).unwrap());
    let last = upstream.len() - 1;
    upstream[last] ^= 1;
    assert!(c.receive(&upstream).is_err());
    for n in 0..upstream.len() {
        assert!(c.receive(&upstream[..n]).is_err())
    }
    assert!(c.receive(&[255, 255, 255, 255, 255, 127]).is_err());
}
#[test]
fn no_audio_before_challenge() {
    let p = parse_version(&fixture(21), 21).unwrap();
    let mut h = Handshake::for_session(&p);
    assert!(h.control(&[10]).is_none());
    assert!(!h.connected);
    assert!(h.control(&[6]).is_none());
    let mut ack = vec![6];
    ack.extend([17; 16]);
    let response = h.control(&ack).unwrap();
    assert_eq!(response[0], 9);
    assert_eq!(&response[1..], &[17; 16]);
    h.control(&[10]);
    assert!(h.connected);
}
#[test]
fn state_list_limits() {
    let mut state = vec![2 | 8 | 32];
    state.extend([1; 16]);
    state.extend([1, b'A']);
    state.extend([2; 16]);
    assert_eq!(
        own_restrictions(&state, false, [1; 16]),
        Ok(Some((true, true)))
    );
    assert!(own_restrictions(&state[..22], false, [1; 16]).is_err());
    assert!(own_restrictions(&[127, 255, 255, 255], true, [0; 16]).is_err());
}
#[test]
fn location_and_group_packets() {
    for id in [3, 4] {
        let mut b = vec![id];
        b.extend([2; 32]);
        if id == 4 {
            for x in [1., 2., 3.] {
                b.extend(f64::to_be_bytes(x))
            }
        }
        b.extend([2, 16, 32]);
        b.extend(3i64.to_be_bytes());
        if id == 4 {
            b.extend(12f32.to_be_bytes())
        }
        b.extend([2, 1, b'X']);
        let p = sound(&b).unwrap();
        assert_eq!(p.opus, [16, 32]);
        for n in 0..b.len() {
            assert!(sound(&b[..n]).is_err())
        }
    }
}
#[cfg(feature = "devices")]
#[test]
fn proximity_orientation_and_missing_entity() {
    use horizon_rede_voice::{
        audio::{gains, Scene},
        wire::Source,
    };
    let mut s = Scene::default();
    assert_eq!(gains(&s, &Source::Player, &[0; 16], 10.), [0.; 2]);
    s.players.insert([0; 16], [5., 0., 0.]);
    assert_eq!(gains(&s, &Source::Player, &[0; 16], 10.), [0.5, 0.]);
    s.yaw = 180.;
    let lr = gains(&s, &Source::Player, &[0; 16], 10.);
    assert!(lr[1] > 0.49 && lr[0] < 0.01);
    assert_eq!(gains(&s, &Source::Player, &[0; 16], 5.), [0.; 2]);
}
