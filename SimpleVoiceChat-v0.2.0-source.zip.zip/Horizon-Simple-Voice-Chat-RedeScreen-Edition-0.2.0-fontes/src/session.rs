use crate::{
    audio::{Devices, Options, Scene},
    secret::SecretPacket,
    wire::{self, Handshake, Transport},
};
use std::io::ErrorKind;
use std::{
    net::{IpAddr, SocketAddr, ToSocketAddrs, UdpSocket},
    sync::{
        atomic::{AtomicBool, AtomicU8, Ordering},
        Arc, Mutex,
    },
    time::{Duration, Instant},
};
const WAIT: Duration = Duration::from_millis(20);
#[derive(Default)]
pub struct Session {
    pub talk: Arc<AtomicBool>,
    pub deaf: Arc<AtomicBool>,
    pub scene: Arc<Mutex<Scene>>,
    pub options: Arc<Mutex<Options>>,
    status: Arc<AtomicU8>,
    stop: Arc<AtomicBool>,
}
impl Drop for Session {
    fn drop(&mut self) {
        self.talk.store(false, Ordering::Release);
        self.stop.store(true, Ordering::Release);
    }
}
impl Session {
    pub fn start(p: SecretPacket, server: String, opts: Options) -> Self {
        let s = Self::default();
        *s.options.lock().unwrap() = opts;
        let options = s.options.clone();
        let deaf = s.deaf.clone();
        let (stop, talk, scene, status) = (
            s.stop.clone(),
            s.talk.clone(),
            s.scene.clone(),
            s.status.clone(),
        );
        std::thread::spawn(move || {
            if run(p, server, options, &stop, talk, &scene, &status, &deaf).is_err() {
                status.store(4, Ordering::Release)
            }
        });
        s
    }
    pub fn device_state(&self) -> Option<(bool, bool)> {
        match self.status.load(Ordering::Acquire) {
            1 => Some((true, false)),
            2 => Some((false, false)),
            3 => Some((true, true)),
            _ => None,
        }
    }
    pub fn ended(&self) -> bool {
        self.status.load(Ordering::Acquire) == 4
    }
    pub fn status(&self) -> &'static str {
        match self.status.load(Ordering::Acquire) {
            0 => "Autenticando UDP",
            1 => "Conectado · sem microfone",
            2 if self.talk.load(Ordering::Acquire) => "Conectado · microfone aberto",
            2 => "Conectado · microfone em espera",
            3 => "Sem saída de áudio",
            _ => "Desconectado",
        }
    }
}
fn host_port(s: &str, default: u16) -> Result<(String, u16), &'static str> {
    if let Ok(a) = s.parse::<SocketAddr>() {
        return Ok((a.ip().to_string(), a.port()));
    }
    if let Ok(ip) = s.trim_matches(&['[', ']'][..]).parse::<IpAddr>() {
        return Ok((ip.to_string(), default));
    }
    let (h, p) = match s.rsplit_once(':') {
        Some((h, p)) => (h, p.parse::<u16>().map_err(|_| "port")?),
        None => (s, default),
    };
    if h.is_empty() || h.chars().any(|c| c.is_whitespace() || "/@?#:".contains(c)) || p == 0 {
        return Err("host");
    }
    Ok((h.to_owned(), p))
}
fn run(
    p: SecretPacket,
    server: String,
    options: Arc<Mutex<Options>>,
    stop: &AtomicBool,
    talk: Arc<AtomicBool>,
    scene: &Mutex<Scene>,
    status: &AtomicU8,
    deaf: &AtomicBool,
) -> Result<(), &'static str> {
    let port = u16::try_from(p.voice_port).map_err(|_| "port")?;
    let (game, _) = host_port(&server, 25565)?;
    let (host, port) = if p.voice_host.is_empty() {
        (game, port)
    } else if let Ok(v) = p.voice_host.parse::<u16>() {
        (game, v)
    } else {
        host_port(&p.voice_host, port)?
    };
    if port == 0 || p.keep_alive <= 0 || p.mtu_size <= 64 {
        return Err("invalid limits");
    }
    let cap = wire::MAX_OPUS.min(p.mtu_size as usize - 64);
    let app = match p.codec_id {
        0 => opus::Application::Voip,
        1 => opus::Application::Audio,
        2 => opus::Application::LowDelay,
        _ => return Err("codec"),
    };
    let mut enc = opus::Encoder::new(48000, opus::Channels::Mono, app).map_err(|_| "opus")?;
    let transport = Transport::new(&p);
    let peer = (host.as_str(), port)
        .to_socket_addrs()
        .map_err(|_| "resolve")?
        .next()
        .ok_or("resolve")?;
    let socket = UdpSocket::bind(if peer.is_ipv4() {
        "0.0.0.0:0"
    } else {
        "[::]:0"
    })
    .map_err(|_| "bind")?;
    socket.connect(peer).map_err(|_| "connect")?;
    socket.set_read_timeout(Some(WAIT)).map_err(|_| "timeout")?;
    let send = |body: &[u8]| {
        if stop.load(Ordering::Acquire) {
            return Err("closed");
        }
        socket
            .send(&transport.send(body)?)
            .map(|_| ())
            .map_err(|_| "udp send")
    };
    let mut opts = options.lock().unwrap().clone();
    let mut hs = Handshake::for_session(&p);
    let mut retry = Instant::now();
    let mut last_alive = Instant::now();
    let mut devices = None;
    let mut seq = 0i64;
    let mut speaking = false;
    let mut buf = [0u8; 2060];
    let mut encoded = [0u8; wire::MAX_OPUS];
    while !stop.load(Ordering::Acquire) {
        if hs.connected {
            let next = options.lock().map_err(|_| "options")?.clone();
            if next.input != opts.input || next.output != opts.output {
                drop(devices.take());
                devices = Devices::open(&next, talk.clone()).ok();
                status.store(
                    match &devices {
                        Some(d) if d.mic => 2,
                        Some(_) => 1,
                        None => 3,
                    },
                    Ordering::Release,
                )
            }
            opts = next;
        }
        if !hs.connected && Instant::now() >= retry {
            send(&hs.retry().unwrap())?;
            retry = Instant::now() + Duration::from_secs(1)
        }
        if last_alive.elapsed()
            > if hs.connected {
                Duration::from_millis(p.keep_alive as u64 * 10)
            } else {
                Duration::from_secs(12)
            }
        {
            return Err("timeout");
        }
        match socket.recv(&mut buf) {
            Ok(n) => {
                if let Ok(body) = transport.receive(&buf[..n]) {
                    if let Ok(s) = wire::sound(&body) {
                        if deaf.load(Ordering::Relaxed) {
                            continue;
                        }
                        if let Some(d) = devices.as_mut() {
                            let d: &mut Devices = d;
                            if let Ok(scene) = scene.lock() {
                                d.play(s, &scene, opts.volume.unwrap_or(1.).clamp(0., 1.))
                            }
                        }
                    } else {
                        let was = hs.connected;
                        if let Some(reply) = hs.control(&body) {
                            send(&reply)?
                        }
                        if hs.connected && (!was || body == [8]) {
                            last_alive = Instant::now()
                        }
                        if !was && hs.connected && !stop.load(Ordering::Acquire) {
                            devices = Devices::open(&opts, talk.clone()).ok();
                            status.store(
                                match &devices {
                                    Some(d) if d.mic => 2,
                                    Some(_) => 1,
                                    None => 3,
                                },
                                Ordering::Release,
                            )
                        }
                    }
                }
            }
            Err(e) if matches!(e.kind(), ErrorKind::WouldBlock | ErrorKind::TimedOut) => {}
            Err(_) => return Err("udp read"),
        }
        if let Some(d) = &devices {
            if d.fault.load(Ordering::Relaxed) {
                return Err("device lost");
            }
            while let Ok(frame) = d.frames.try_recv() {
                if !talk.load(Ordering::Relaxed) {
                    continue;
                }
                if let Ok(n) = enc.encode(&frame, &mut encoded[..cap]) {
                    send(&wire::mic(&encoded[..n], seq, false)?)?;
                    seq = seq.wrapping_add(1);
                    speaking = true
                }
            }
            if speaking && !talk.load(Ordering::Relaxed) {
                send(&wire::mic(&[], seq, false)?)?;
                seq = seq.wrapping_add(1);
                speaking = false
            }
        }
    }
    Ok(())
}
