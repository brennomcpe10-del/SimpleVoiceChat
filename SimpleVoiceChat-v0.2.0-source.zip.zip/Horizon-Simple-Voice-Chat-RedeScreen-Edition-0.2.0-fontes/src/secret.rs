#[derive(Debug, PartialEq)]
pub enum ParseError {
    Truncated,
    InvalidBool,
    InvalidUtf8,
    InvalidLength,
    TooLong,
    TrailingBytes,
}

#[derive(Clone, PartialEq)]
pub struct SecretPacket {
    // Kept in memory only. Never write this secret into logs or files.
    pub protocol: i32,
    pub secret: [u8; 16],
    pub connection_id: [u8; 16],
    pub voice_port: i32,
    pub player_uuid: [u8; 16],
    pub codec_id: u8,
    pub mtu_size: i32,
    pub voice_chat_distance: f64,
    pub keep_alive: i32,
    pub groups_enabled: bool,
    pub voice_host: String,
    pub allow_recording: bool,
}

struct Reader<'a> {
    bytes: &'a [u8],
    offset: usize,
}
impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> Result<&'a [u8], ParseError> {
        let end = self
            .offset
            .checked_add(n)
            .ok_or(ParseError::InvalidLength)?;
        let v = self
            .bytes
            .get(self.offset..end)
            .ok_or(ParseError::Truncated)?;
        self.offset = end;
        Ok(v)
    }
    fn byte(&mut self) -> Result<u8, ParseError> {
        Ok(self.take(1)?[0])
    }
    fn i32(&mut self) -> Result<i32, ParseError> {
        Ok(i32::from_be_bytes(self.take(4)?.try_into().unwrap()))
    }
    fn f64(&mut self) -> Result<f64, ParseError> {
        Ok(f64::from_be_bytes(self.take(8)?.try_into().unwrap()))
    }
    fn id(&mut self) -> Result<[u8; 16], ParseError> {
        Ok(self.take(16)?.try_into().unwrap())
    }
    fn bool(&mut self) -> Result<bool, ParseError> {
        match self.byte()? {
            0 => Ok(false),
            1 => Ok(true),
            _ => Err(ParseError::InvalidBool),
        }
    }
    fn varint(&mut self) -> Result<usize, ParseError> {
        let mut out: u32 = 0;
        for i in 0..5 {
            let b = self.byte()?;
            if i == 4 && b & 0xF0 != 0 {
                return Err(ParseError::InvalidLength);
            }
            out |= ((b & 0x7f) as u32) << (7 * i);
            if b & 0x80 == 0 {
                return Ok(out as usize);
            }
        }
        Err(ParseError::InvalidLength)
    }
    fn string(&mut self, max_chars: usize) -> Result<String, ParseError> {
        // Minecraft readUtf(32767) permits at most 3 * chars encoded bytes.
        let n = self.varint()?;
        if n > max_chars * 3 {
            return Err(ParseError::TooLong);
        }
        let text = std::str::from_utf8(self.take(n)?).map_err(|_| ParseError::InvalidUtf8)?;
        if text.encode_utf16().count() > max_chars {
            return Err(ParseError::TooLong);
        }
        Ok(text.to_owned())
    }
}

pub fn parse_secret_packet(bytes: &[u8]) -> Result<SecretPacket, ParseError> {
    parse_version(bytes, 21)
}
pub fn parse_version(bytes: &[u8], protocol: i32) -> Result<SecretPacket, ParseError> {
    if protocol != 20 && protocol != 21 {
        return Err(ParseError::InvalidLength);
    }
    let mut r = Reader { bytes, offset: 0 };
    let secret = r.id()?;
    let connection_id = if protocol == 21 { Some(r.id()?) } else { None };
    let voice_port = r.i32()?;
    let player_uuid = r.id()?;
    let codec_id = r.byte()?;
    let mtu_size = r.i32()?;
    let voice_chat_distance = r.f64()?;
    let keep_alive = r.i32()?;
    let groups_enabled = r.bool()?;
    let voice_host = r.string(32767)?;
    let allow_recording = r.bool()?;
    if r.offset != bytes.len() {
        return Err(ParseError::TrailingBytes);
    }
    Ok(SecretPacket {
        protocol,
        secret,
        connection_id: connection_id.unwrap_or(player_uuid),
        voice_port,
        player_uuid,
        codec_id,
        mtu_size,
        voice_chat_distance,
        keep_alive,
        groups_enabled,
        voice_host,
        allow_recording,
    })
}

// RequestSecretPacket uses writeInt/readInt (big endian), not Minecraft VarInt.
pub fn encode_request_secret(compatibility_version: i32) -> [u8; 4] {
    compatibility_version.to_be_bytes()
}

#[cfg(test)]
mod tests {
    use super::*;
    fn fixture() -> Vec<u8> {
        let mut b = vec![0x11; 16]; // Secret
        b.extend([0x22; 16]); // Connection UUID
        b.extend(24454i32.to_be_bytes());
        b.extend([0x33; 16]); // Player UUID
        b.push(0); // Codec enum ID
        b.extend(1024i32.to_be_bytes());
        b.extend(48.0f64.to_be_bytes());
        b.extend(1000i32.to_be_bytes());
        b.push(1); // Groups enabled
        b.push(9); // Minecraft UTF VarInt length
        b.extend(b"127.0.0.1");
        b.push(0); // Recording not allowed
        b
    }
    #[test]
    fn reads_full_secret_packet_without_exposing_secret() {
        let p = parse_secret_packet(&fixture()).unwrap();
        assert_eq!(p.voice_port, 24454);
        assert_eq!(p.voice_host, "127.0.0.1");
        assert_eq!(p.voice_chat_distance, 48.0);
        assert_eq!(p.connection_id, [0x22; 16]);
        assert!(p.groups_enabled);
        assert!(!p.allow_recording);
    }
    #[test]
    fn rejects_truncation_and_trailing_data() {
        let mut b = fixture();
        assert!(matches!(
            parse_secret_packet(&b[..b.len() - 1]),
            Err(ParseError::Truncated)
        ));
        b.push(9);
        assert!(matches!(
            parse_secret_packet(&b),
            Err(ParseError::TrailingBytes)
        ));
    }
    #[test]
    fn request_secret_is_big_endian_i32() {
        assert_eq!(encode_request_secret(0x01020304), [1, 2, 3, 4]);
    }
    #[test]
    fn malformed_utf_and_bool_are_rejected() {
        let mut b = fixture();
        b[16 + 16 + 4 + 16 + 1 + 4 + 8 + 4] = 2;
        assert!(matches!(
            parse_secret_packet(&b),
            Err(ParseError::InvalidBool)
        ));
    }
}
