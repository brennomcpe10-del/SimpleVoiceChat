use crate::wire::{Sound, Source};
use cpal::{
    traits::{DeviceTrait, HostTrait, StreamTrait},
    Device, FromSample, Sample, SampleFormat, SizedSample, Stream, StreamConfig,
};
use std::{
    collections::{HashMap, VecDeque},
    sync::{
        atomic::{AtomicBool, Ordering},
        mpsc::{sync_channel, Receiver},
        Arc, Mutex,
    },
    time::{Duration, Instant},
};
pub const FRAME: usize = 960;
pub type Frame = [i16; FRAME];
#[derive(Default)]
pub struct Scene {
    pub listener: [f64; 3],
    pub yaw: f32,
    pub players: HashMap<[u8; 16], [f64; 3]>,
}
pub fn gains(scene: &Scene, source: &Source, sender: &[u8; 16], distance: f32) -> [f32; 2] {
    let p = match source {
        Source::Group => return [1.; 2],
        Source::Location(p) => p,
        Source::Player => match scene.players.get(sender) {
            Some(p) => p,
            None => return [0.; 2],
        },
    };
    let [x, y, z] = std::array::from_fn(|i| p[i] - scene.listener[i]);
    let d = x.hypot(z).hypot(y);
    if distance <= 0. || !d.is_finite() || d >= distance as f64 {
        return [0.; 2];
    }
    let yaw = f64::from(scene.yaw).to_radians();
    let pan = if d > 0. {
        (-x * yaw.cos() - z * yaw.sin()) / d
    } else {
        0.
    };
    let gain = (1. - d / distance as f64) as f32;
    [
        gain * (1. - pan.max(0.) as f32),
        gain * (1. + pan.min(0.) as f32),
    ]
}
struct Channel {
    decoder: opus::Decoder,
    last: Option<i64>,
    seen: Instant,
}
type Queues = Arc<Mutex<HashMap<[u8; 16], VecDeque<[f32; 2]>>>>;
pub struct Devices {
    _output: Stream,
    _input: Option<Stream>,
    pub frames: Receiver<Frame>,
    queues: Queues,
    channels: HashMap<[u8; 16], Channel>,
    pub fault: Arc<AtomicBool>,
    pub mic: bool,
}
#[derive(Clone, Default)]
pub struct Options {
    pub input: Option<String>,
    pub output: Option<String>,
    pub open: bool,
    pub volume: Option<f32>,
}
fn device(input: bool, name: &Option<String>) -> Result<Device, &'static str> {
    let h = cpal::default_host();
    if let Some(name) = name {
        let mut devices = if input {
            h.input_devices()
        } else {
            h.output_devices()
        }
        .map_err(|_| "device list")?;
        devices
            .find(|d| d.name().ok().as_ref() == Some(name))
            .ok_or("device unavailable")
    } else {
        (if input {
            h.default_input_device()
        } else {
            h.default_output_device()
        })
        .ok_or("no default device")
    }
}
fn rate(r: &cpal::SupportedStreamConfigRange) -> u32 {
    48000u32.clamp(r.min_sample_rate().0, r.max_sample_rate().0)
}
// Integer phase keeps duration exact across device callbacks, including at 44.1 kHz.
struct To48 {
    hz: u32,
    phase: u32,
    prev: f32,
}
impl To48 {
    fn new(hz: u32) -> Self {
        Self {
            hz,
            phase: hz,
            prev: 0.,
        }
    }
    fn push(&mut self, value: f32, mut emit: impl FnMut(f32)) {
        if self.hz == 48000 {
            emit(value);
            return;
        }
        while self.phase <= 48000 {
            emit(self.prev + (value - self.prev) * (self.phase as f32 / 48000.));
            self.phase += self.hz;
        }
        self.phase -= 48000;
        self.prev = value;
    }
}
#[cfg(test)]
mod rates {
    use super::*;
    #[test]
    fn one_second_is_48000_samples() {
        for hz in [16000, 44100, 48000, 96000] {
            let mut r = To48::new(hz);
            let mut count = 0;
            for _ in 0..hz {
                r.push(0.25, |v| {
                    assert!((0.0..=0.25).contains(&v));
                    count += 1
                })
            }
            assert_eq!(count, 48000)
        }
    }
}
fn config(d: &Device, input: bool) -> Result<(StreamConfig, SampleFormat), &'static str> {
    let ranges: Vec<_> = if input {
        d.supported_input_configs()
            .map_err(|_| "input formats")?
            .collect()
    } else {
        d.supported_output_configs()
            .map_err(|_| "output formats")?
            .collect()
    };
    let r = ranges
        .into_iter()
        .filter(|r| {
            r.min_sample_rate().0 <= 192000
                && r.max_sample_rate().0 >= 8000
                && matches!(
                    r.sample_format(),
                    SampleFormat::F32 | SampleFormat::I16 | SampleFormat::U16
                )
        })
        .min_by_key(|r| {
            (
                rate(r).abs_diff(48000),
                r.channels().abs_diff(if input { 1 } else { 2 }),
                r.sample_format() != SampleFormat::F32,
            )
        })
        .ok_or("no supported PCM format")?;
    let fmt = r.sample_format();
    let hz = rate(&r);
    Ok((r.with_sample_rate(cpal::SampleRate(hz)).config(), fmt))
}
fn capture<T: SizedSample + Sample>(
    d: &Device,
    c: &StreamConfig,
    talk: Arc<AtomicBool>,
    tx: std::sync::mpsc::SyncSender<Frame>,
    bad: Arc<AtomicBool>,
) -> Result<Stream, &'static str>
where
    f32: FromSample<T>,
{
    let mut rate = To48::new(c.sample_rate.0);
    let mut frame = [0; FRAME];
    let mut offset = 0;
    let channels = c.channels as usize;
    d.build_input_stream(
        c,
        move |data: &[T], _| {
            if !talk.load(Ordering::Relaxed) {
                offset = 0;
                rate.phase = rate.hz;
                rate.prev = 0.;
                return;
            }
            for p in data.chunks_exact(channels) {
                let value = p.iter().map(|s| s.to_sample::<f32>()).sum::<f32>() / channels as f32;
                rate.push(value, |value| {
                    frame[offset] = (value.clamp(-1., 1.) * 32767.) as i16;
                    offset += 1;
                    if offset == FRAME {
                        let _ = tx.try_send(frame);
                        offset = 0
                    }
                });
            }
        },
        move |_| bad.store(true, Ordering::Relaxed),
        None,
    )
    .map_err(|_| "open input")
}
fn playback<T: SizedSample + FromSample<f32>>(
    d: &Device,
    c: &StreamConfig,
    q: Queues,
    bad: Arc<AtomicBool>,
) -> Result<Stream, &'static str> {
    let channels = c.channels as usize;
    let hz = c.sample_rate.0;
    let mut phase = 0;
    let mut previous = [0.; 2];
    let mut current = [0.; 2];
    d.build_output_stream(
        c,
        move |data: &mut [T], _| {
            data.fill(T::from_sample(0.));
            let Ok(mut queues) = q.try_lock() else { return };
            for p in data.chunks_exact_mut(channels) {
                phase += 48000;
                while phase >= hz {
                    phase -= hz;
                    previous = current;
                    current = [0.; 2];
                    for v in queues.values_mut() {
                        if let Some(s) = v.pop_front() {
                            current[0] += s[0];
                            current[1] += s[1]
                        }
                    }
                }
                let lr = if hz == 48000 {
                    current
                } else {
                    std::array::from_fn(|i| {
                        previous[i] + (current[i] - previous[i]) * phase as f32 / hz as f32
                    })
                };
                if channels == 1 {
                    p[0] = T::from_sample(((lr[0] + lr[1]) * 0.5).clamp(-1., 1.))
                } else {
                    for i in 0..2 {
                        p[i] = T::from_sample(lr[i].clamp(-1., 1.))
                    }
                }
            }
            queues.retain(|_, v| !v.is_empty());
        },
        move |_| bad.store(true, Ordering::Relaxed),
        None,
    )
    .map_err(|_| "open output")
}
impl Devices {
    pub fn open(opts: &Options, talk: Arc<AtomicBool>) -> Result<Self, &'static str> {
        let q = Queues::default();
        let bad = Arc::new(AtomicBool::new(false));
        let d = device(false, &opts.output)?;
        let (c, f) = config(&d, false)?;
        let out = match f {
            SampleFormat::F32 => playback::<f32>,
            SampleFormat::I16 => playback::<i16>,
            _ => playback::<u16>,
        }(&d, &c, q.clone(), bad.clone())?;
        out.play().map_err(|_| "start output")?;
        let (tx, frames) = sync_channel(3);
        let input = (|| {
            let d = device(true, &opts.input)?;
            let (c, f) = config(&d, true)?;
            let s = match f {
                SampleFormat::F32 => capture::<f32>,
                SampleFormat::I16 => capture::<i16>,
                _ => capture::<u16>,
            }(&d, &c, talk, tx, bad.clone())?;
            s.play().map_err(|_| "start input")?;
            Ok::<_, &str>(s)
        })()
        .ok();
        Ok(Self {
            _output: out,
            mic: input.is_some(),
            _input: input,
            frames,
            queues: q,
            channels: HashMap::new(),
            fault: bad,
        })
    }
    pub fn play(&mut self, s: Sound<'_>, scene: &Scene, volume: f32) {
        let gains = gains(scene, &s.source, &s.sender, s.distance);
        if s.opus.is_empty() {
            self.channels.remove(&s.channel);
            return;
        }
        if gains == [0.; 2] {
            return;
        }
        if !self.channels.contains_key(&s.channel) {
            self.channels
                .retain(|_, c| c.seen.elapsed() < Duration::from_secs(4));
            if self.channels.len() >= 32 {
                return;
            }
            let Ok(decoder) = opus::Decoder::new(48000, opus::Channels::Mono) else {
                return;
            };
            self.channels.insert(
                s.channel,
                Channel {
                    decoder,
                    last: None,
                    seen: Instant::now(),
                },
            );
        }
        let c = self.channels.get_mut(&s.channel).unwrap();
        if c.last.is_some_and(|last| s.seq >= 0 && last >= s.seq) {
            return;
        }
        let mut pcm = [0; FRAME];
        let Ok(n) = c.decoder.decode(s.opus, &mut pcm, false) else {
            return;
        };
        c.last = Some(s.seq);
        c.seen = Instant::now();
        let Ok(mut queues) = self.queues.lock() else {
            return;
        };
        if !queues.contains_key(&s.channel) && queues.len() >= 32 {
            return;
        }
        let queue = queues.entry(s.channel).or_default();
        while queue.len() + n > FRAME * 4 {
            queue.pop_front();
        }
        for &sample in &pcm[..n] {
            queue.push_back(gains.map(|gain| gain * volume * sample as f32 / 32768.))
        }
    }
}
pub fn device_names(input: bool) -> Vec<String> {
    let h = cpal::default_host();
    let devices = if input {
        h.input_devices()
    } else {
        h.output_devices()
    };
    devices
        .into_iter()
        .flatten()
        .filter_map(|d| d.name().ok())
        .take(64)
        .collect()
}
