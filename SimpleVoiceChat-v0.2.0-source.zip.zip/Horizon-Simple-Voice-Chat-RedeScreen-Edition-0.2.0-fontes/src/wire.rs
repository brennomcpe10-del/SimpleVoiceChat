// Wire layout from NetworkMessage, ClientNetworkMessage and voice/common/*Packet (compat 21).
use crate::secret::SecretPacket;
use aes_gcm::{
    aead::{Aead, KeyInit},
    Aes128Gcm, Nonce,
};

pub const REQUEST: [u8; 4] = 21i32.to_be_bytes();
const MAX_CIPHER: usize = 2048;
pub const MAX_OPUS: usize = 1275;
type Result<T> = std::result::Result<T, &'static str>;
fn var(mut n: usize, out: &mut Vec<u8>) {
    while n >= 128 {
        out.push(n as u8 | 128);
        n >>= 7;
    }
    out.push(n as u8);
}
struct Reader<'a>(&'a [u8]);
impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> Result<&'a [u8]> {
        if n > self.0.len() {
            return Err("truncated");
        }
        let (a, b) = self.0.split_at(n);
        self.0 = b;
        Ok(a)
    }
    fn fixed<const N: usize>(&mut self) -> Result<[u8; N]> {
        Ok(self.take(N)?.try_into().unwrap())
    }
    fn array(&mut self, max: usize) -> Result<&'a [u8]> {
        let mut n = 0u32;
        for shift in [0, 7, 14, 21, 28] {
            let b = self.fixed::<1>()?[0];
            if shift == 28 && b > 7 {
                return Err("length overflow");
            }
            n |= u32::from(b & 127) << shift;
            if b < 128 {
                return if n as usize <= max {
                    self.take(n as usize)
                } else {
                    Err("oversize")
                };
            }
        }
        Err("invalid length")
    }
}
pub struct Transport {
    cipher: Aes128Gcm,
    connection: [u8; 16],
}
impl Transport {
    pub fn new(p: &SecretPacket) -> Self {
        Self {
            cipher: Aes128Gcm::new((&p.secret).into()),
            connection: p.connection_id,
        }
    }
    pub fn send(&self, body: &[u8]) -> Result<Vec<u8>> {
        if body.is_empty() || body.len() + 28 > MAX_CIPHER {
            return Err("invalid packet size");
        }
        let mut iv = [0; 12];
        getrandom::getrandom(&mut iv).map_err(|_| "rng")?;
        let ct = self
            .cipher
            .encrypt(Nonce::from_slice(&iv), body)
            .map_err(|_| "encrypt")?;
        let mut out = vec![255];
        out.extend(self.connection);
        var(12 + ct.len(), &mut out);
        out.extend(iv);
        out.extend(ct);
        Ok(out)
    }
    pub fn receive(&self, data: &[u8]) -> Result<Vec<u8>> {
        let mut r = Reader(data);
        if r.fixed::<1>()? != [255] {
            return Err("magic");
        }
        let payload = r.array(MAX_CIPHER)?;
        if !r.0.is_empty() || payload.len() < 29 {
            return Err("size");
        }
        self.cipher
            .decrypt(Nonce::from_slice(&payload[..12]), &payload[12..])
            .map_err(|_| "authentication")
    }
}
pub fn mic(opus: &[u8], seq: i64, whisper: bool) -> Result<Vec<u8>> {
    if opus.len() > MAX_OPUS {
        return Err("oversize opus");
    }
    let mut out = vec![1];
    var(opus.len(), &mut out);
    out.extend(opus);
    out.extend(seq.to_be_bytes());
    out.push(whisper as u8);
    Ok(out)
}
pub enum Source {
    Player,
    Group,
    Location([f64; 3]),
}
pub struct Sound<'a> {
    pub source: Source,
    pub channel: [u8; 16],
    pub sender: [u8; 16],
    pub opus: &'a [u8],
    pub seq: i64,
    pub distance: f32,
}
pub fn sound(bytes: &[u8]) -> Result<Sound<'_>> {
    let mut r = Reader(bytes);
    let id = r.fixed::<1>()?[0];
    let channel = r.fixed()?;
    let sender = r.fixed()?;
    let source = match id {
        2 => Source::Player,
        3 => Source::Group,
        4 => {
            let mut p = [0.; 3];
            for x in &mut p {
                *x = f64::from_be_bytes(r.fixed()?);
                if !x.is_finite() {
                    return Err("position");
                }
            }
            Source::Location(p)
        }
        _ => return Err("type"),
    };
    let opus = r.array(MAX_OPUS)?;
    let seq = i64::from_be_bytes(r.fixed()?);
    let distance = if id == 3 {
        0.
    } else {
        f32::from_be_bytes(r.fixed()?)
    };
    if !distance.is_finite() || distance < 0. {
        return Err("distance");
    }
    if r.fixed::<1>()?[0] & 2 != 0 {
        let cat = std::str::from_utf8(r.array(48)?).map_err(|_| "category")?;
        if cat.encode_utf16().count() > 16 {
            return Err("category");
        }
    }
    if !r.0.is_empty() {
        return Err("trailing");
    }
    Ok(Sound {
        source,
        channel,
        sender,
        opus,
        seq,
        distance,
    })
}
#[derive(Default)]
pub struct Handshake {
    challenge: Option<[u8; 16]>,
    legacy: Option<([u8; 16], [u8; 16])>,
    pub connected: bool,
}
impl Handshake {
    pub fn for_session(p: &SecretPacket) -> Self {
        Self {
            legacy: (p.protocol == 20).then_some((p.player_uuid, p.secret)),
            ..Self::default()
        }
    }
    pub fn retry(&self) -> Option<Vec<u8>> {
        if self.connected {
            return None;
        }
        if let Some((id, key)) = self.legacy {
            if self.challenge.is_some() {
                return Some(vec![9]);
            }
            let mut p = vec![5];
            p.extend(id);
            p.extend(key);
            return Some(p);
        }
        if let Some(n) = self.challenge {
            let mut p = vec![9];
            p.extend(n);
            Some(p)
        } else {
            Some(vec![5])
        }
    }
    pub fn control(&mut self, p: &[u8]) -> Option<Vec<u8>> {
        match p {
            [6] if self.legacy.is_some() && !self.connected => {
                self.challenge = Some([0; 16]);
                self.retry()
            }
            [6, n @ ..] if self.legacy.is_none() && n.len() == 16 && !self.connected => {
                self.challenge = n.try_into().ok();
                self.retry()
            }
            [10] if self.challenge.is_some() => {
                self.connected = true;
                None
            }
            [8] if self.connected => Some(vec![8]),
            [7, rest @ ..] if rest.len() == 24 => Some(p.to_vec()),
            _ => None,
        }
    }
}
// 2.7 PlayerStatePacket / PlayerStatesPacket: consult only this client's flags.
pub fn own_restrictions(data: &[u8], list: bool, own: [u8; 16]) -> Result<Option<(bool, bool)>> {
    let mut r = Reader(data);
    let count = if list {
        i32::from_be_bytes(r.fixed()?)
    } else {
        1
    };
    if !(0..=8192).contains(&count) {
        return Err("state count");
    }
    let mut found = None;
    for _ in 0..count {
        let flags = r.fixed::<1>()?[0];
        let id = r.fixed::<16>()?;
        let name = std::str::from_utf8(r.array(768)?).map_err(|_| "name")?;
        if name.encode_utf16().count() > 256 {
            return Err("name");
        }
        if flags & 32 != 0 {
            r.fixed::<16>()?;
        }
        if id == own {
            found = Some((flags & 2 != 0, flags & 8 != 0))
        }
    }
    if !r.0.is_empty() {
        return Err("trailing state");
    }
    Ok(found)
}
