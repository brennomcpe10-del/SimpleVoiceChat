# Resultados de homologação · 31/10/2026

**Classificação:** integração de desenvolvimento com interoperabilidade local demonstrada. Uso no RedeScreen pendente. Nenhum teste usou conta real, servidor público, microfone pessoal ou gravação de conversa.

| Teste | Resultado | Alcance |
|---|---|---|
| Manifesto recebido | Íntegro. Recusado na revisão atual com E_REVISION. | O ZIP original contém um mod de diagnóstico fixado em 6f8c7a0e. |
| Manifesto com as dependências de voz | Recusado com E_CRATE_DEPENDENCY. | Resultado da CLI oficial sobre a revisão base limpa. A documentação do template orienta materializar o link simbólico do arquivo de documentação para usar a CLI. |
| Compilação do núcleo e do jogo | Passou em Linux e em compilação cruzada do jogo completo para Windows x64. | Rust 1.99.1. No Windows foram compilados os recursos padrão do cliente. Os logs incluem uma compilação incremental. |
| Inicialização do cliente | CLI Linux executou e mostrou a ajuda do Horizon 26.3. A tentativa de inicialização gráfica terminou com código 1. | Ausência de recursos preparados e de uma sessão gráfica. O menu e a entrada em um mundo não foram validados. A integração é compilada no cliente, sem carregamento dinâmico de mod. |
| Entrada e saída | Passou com dispositivos ALSA virtuais e o worker de produção. | Um tom de teste percorreu captura, push-to-talk, UDP e saída. Microfone e alto-falantes físicos e WASAPI no Windows estão pendentes. |
| Protocolo Minecraft e áudio | Passou para compatibilidades 20 e 21. | Sessão TCP real do Horizon, login local sintético, fase de configuração e pacotes de voz em play. O emissor de Minecraft é uma fixture e o worker de áudio é o do produto. |
| UDP e Opus | Passou para 20 e 21. | AES-GCM, auth/ack, connection check, keep-alive, mic, retorno de áudio Opus e fim de transmissão ao soltar a tecla. Para 21, o servidor de teste envia desafio e verifica o eco. |
| Plugin Bukkit publicado | Passou com as classes do JAR original 2.6.27, SHA-512 verificado. | No pacote que volta do servidor, o próprio NetworkMessage do JAR escolhe o tipo, serializa e cifra. O teste usa um par UDP local com as classes do plugin. Não inicia um servidor Minecraft com o plugin instalado. |
| Posição | Passou com fonte à direita no dispositivo virtual. | Energia medida no arquivo de saída: esquerda 0, direita aproximadamente 133. Testes unitários cobrem rotação, entidade ausente e distância fora do raio. |
| Limites e validação | 11 testes Rust passaram. | Incluem truncamento dos dois layouts, tamanho, tag AES inválida, fase do desafio, flags do próprio jogador, categorias, grupo/localização e conversão de frequência. |
| Custo isolado | 60 segundos de áudio de um locutor processados em 0,286 s. RSS máximo 6.188 KiB. | Microbenchmark otimizado de 3.000 quadros em uma máquina Linux de desenvolvimento. Exclui o jogo, callbacks físicos, UI e rede real. |
| Cliente Windows | Compilação e inspeção PE32+ x86-64 passaram. | SHA-256 do build de desenvolvimento em `logs/windows-pe.txt`. Wine não iniciou devido à restrição de socket do ambiente. Teste nativo e verificação com Defender não realizados. O binário não acompanha o ZIP. |
| Continuidade e recursos do servidor | Parcial. | Há lógica de timeout, repetição, seleção de dispositivos e HUD. Trocas reais de servidor/dispositivo, reconexão após perda de rede, UI no jogo, desempenho no PC do jogador e regras específicas de proxies/plugins ainda precisam de teste. |
| RedeScreen | Não testado. | Versão/configuração do plugin e compatibilidade com o servidor não confirmadas. |

## Como repetir o ensaio de interoperabilidade

Use uma máquina Linux de desenvolvimento, com Cargo/Rust 1.99.1, JDK 17 ou posterior para o par de referência, ALSA com os PCMs null/file, CMake e as bibliotecas de compilação do Horizon. O teste cria e remove dispositivos virtuais por configuração temporária do próprio processo. Não altera o áudio do sistema.

1. Faça dois checkouts do repositório oficial henkelmax/simple-voice-chat, um por revisão fixada em `compatibility.json`. O executor recusa outra revisão.
2. Prepare os JARs de teste com `python tools/fetch_test_netty.py /tmp/voice-netty`. O script confere o SHA-256 de cada arquivo obtido do Maven Central.
3. Na raiz do projeto, rode os comandos abaixo, substituindo os dois caminhos de checkout.

```sh
cargo test --locked --features devices
python tests/interop/run.py /caminho/svc20 /tmp/voice-netty --virtual --horizon horizon
python tests/interop/run.py /caminho/svc21 /tmp/voice-netty --virtual --horizon horizon
```

Para usar o artefato publicado, baixe o JAR oficial `voicechat-bukkit-2.6.27.jar` da versão indicada em `FONTES.md` e acrescente `--plugin /caminho/voicechat-bukkit-2.6.27.jar` ao comando de protocolo 20. O teste recusa um SHA-512 diferente. O JAR não é instalado no Horizon.

Nos testes por fonte, o JDK compila as classes upstream FriendlyByteBuf, Secret e classes de pacotes, com adaptadores pequenos para o contexto externo de teste. O par Java liga somente em 127.0.0.1. No teste do artefato publicado, as classes de referência vêm do próprio JAR; não há adaptadores de implementação do plugin. O teste TCP atribui um UUID de laboratório e o vincula ao payload de voz. O protocolo de login do jogo e a autenticação da conta do Horizon permanecem os originais.

Para repetir a medição de custo do núcleo em Linux:

```sh
cargo build --release --locked --example cost
python tools/bench.py
```

## Critério para uma versão de instalação

Ainda é preciso iniciar o cliente qualificado no Windows com recursos preparados da edição 26.3, abrir o menu V, validar entrada/saída e conversar nos dois sentidos com um cliente Simple Voice Chat em um servidor autorizado. Para afirmar compatibilidade com o RedeScreen, repetir lá, incluindo a distância e a reconexão. O teste de duas pessoas está em `WINDOWS.md`.
