# Windows 64 bits

## O que fazer com este download

Extraia o ZIP para ler o projeto e os logs. Este ZIP não é um mod importável. Não há `.exe` nem `.hnmod` de voz nele. O `.hnmod` do protótipo recebido só aciona um diagnóstico ao apertar V.

O cliente Windows já compilou fora do seu PC. Falta qualificá-lo em Windows com os recursos do Horizon e áudio real. O workflow manual da pasta `.github/workflows/` permite produzir uma candidata em um repositório GitHub dedicado: executa os testes Rust e a troca UDP com o par Java, compila o jogo completo, executa `--help`, verifica o candidato com o Defender e gera o SHA-256. O fluxo não foi disparado nesta entrega. O sucesso desse fluxo, sozinho, ainda exige o teste abaixo.

## Como instalar uma candidata já verificada, em uma instância de teste

Este procedimento é para a etapa em que houver um `horizon-client.exe` qualificado, com hash publicado e compatibilidade documentada. O launcher mantém cada versão em sua própria pasta. O fluxo de build nativo do próprio Horizon copia uma versão instalada com seus recursos e coloca o novo cliente nessa cópia. A integração usa esse modelo.

1. Confira o hash **antes de executar**. No PowerShell, na pasta que contém a candidata, use `Get-FileHash .\horizon-client.exe -Algorithm SHA256`. Compare os 64 caracteres com o SHA-256 do build específico. Faça a verificação do arquivo com o Microsoft Defender.
2. Feche o Horizon. Com a revisão base confirmada, localize a **pasta da versão** 26.3 oficial que já abre o jogo. Normalmente fica em `%APPDATA%\horizon-launcher\versions`. Se você personalizou `HORIZON_LAUNCHER_HOME`, use a subpasta `versions` daquele local.
3. Faça uma cópia completa dessa pasta **ao lado dela**, com o nome `26.3-voice-redescreen-teste`. Dentro **apenas da cópia**, coloque o novo `horizon-client.exe` no lugar do executável do jogo. Use uma versão base oficial com recursos preparados e sem outros mods nativos. A pasta de contas e a pasta de mundos não são necessárias para fazer essa cópia.
4. Abra o launcher habitual, selecione a versão copiada em uma instância nova para testes e entre pela sua sessão normal. Se a versão não aparecer ou se o jogo pedir os recursos preparados, pare nessa etapa e confirme o caminho e a revisão. O projeto não pede senha, token ou arquivo de conta.

## Teste final com outra pessoa

- Entre no RedeScreen normalmente. Pressione **V**, confira a entrada e a saída e deixe em **push-to-talk**. Anote se o HUD chega a **Conectado**.
- Fique perto de um jogador com Simple Voice Chat funcional. Segure **Alt esquerdo**, diga uma frase curta e solte. Peça que ele repita o que ouviu e responda. Confirme que, com a tecla solta, sua fala não chega ao outro lado.
- Peça que ele fale enquanto você gira e se afasta. Confira esquerda/direita e queda do volume até o silêncio. Troque a saída no menu e repita.
- Ative **Microfone aberto** para uma frase, volte a push-to-talk e confirme a diferença. Saia do servidor e entre novamente para conferir a reconexão.
- Para relatar uma falha, bastam a versão do Horizon, a fase indicada no HUD, a direção que falhou (ouvir/falar) e os dispositivos usados. Não envie credenciais, arquivos de sessão nem capturas de pacotes.

## Desinstalação da candidata

Feche o jogo, volte a selecionar a versão original e exclua a pasta `26.3-voice-redescreen-teste` criada no passo 3. Se tiver criado uma instância de teste separada, remova-a somente após guardar eventuais mundos que criou nela.
